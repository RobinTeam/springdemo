package com.dudu.app.dao;

import com.dudu.app.common.BaseDao;
import com.dudu.app.entity.User;

public interface UserDao extends BaseDao<User, String> {
}
