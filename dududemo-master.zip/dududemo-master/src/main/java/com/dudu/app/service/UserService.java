package com.dudu.app.service;

import com.dudu.app.common.BaseService;
import com.dudu.app.entity.User;

public interface UserService extends BaseService<User>  {
	
}
